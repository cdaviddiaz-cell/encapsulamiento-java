public class ejercicio_2 {
    public static void main(String[] args) {
        // Crear un objeto de tipo Temperatura
        Temperatura temp = new Temperatura(20.0);

        // Mostrar temperatura inicial
        temp.mostrarTemperatura();

        // Aumentar la temperatura
        temp.aumentar(10.0);
        temp.mostrarTemperatura();

        // Disminuir la temperatura
        temp.disminuir(5.0);
        temp.mostrarTemperatura();

        // Intentar disminuir por debajo del cero absoluto
        temp.disminuir(300.0);
        temp.mostrarTemperatura();
    }
}

class Temperatura {
    private double celsius;

    // Constructor
    public Temperatura(double celsius) {
        this.celsius = celsius;
    }

    // Método para aumentar la temperatura
    public void aumentar(double cantidad) {
        this.celsius += cantidad;
        System.out.println("Temperatura aumentada en " + cantidad + " °C.");
    }

    // Método para disminuir la temperatura con validación
    public void disminuir(double cantidad) {
        double nuevaTemperatura = this.celsius - cantidad;
        if (nuevaTemperatura >= -273.15) {
            this.celsius = nuevaTemperatura;
            System.out.println("Temperatura disminuida en " + cantidad + " °C.");
        } else {
            System.out.println("Error: No se puede disminuir la temperatura por debajo del cero absoluto (-273.15 °C).");
        }
    }

    // Método para mostrar la temperatura actual
    public void mostrarTemperatura() {
        System.out.println("Temperatura actual: " + celsius + " °C");
        System.out.println();
    }
}