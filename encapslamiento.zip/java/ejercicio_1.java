public class ejercicio_1 {
    public static void main(String[] args) {
        // Crear un objeto de tipo Libro
        Libro libro = new Libro("El Quijote", "Miguel de Cervantes", 1000);

        // Mostrar información inicial
        libro.mostrarInformacion();

        // Modificar el número de páginas con un valor válido
        libro.actualizarPaginas(1200);
        libro.mostrarInformacion();

        // Intentar asignar un valor inválido
        libro.actualizarPaginas(-50);
        libro.mostrarInformacion();
    }
}

class Libro {
    private String titulo;
    private String autor;
    private int numeroPaginas;

    // Constructor
    public Libro(String titulo, String autor, int numeroPaginas) {
        this.titulo = titulo;
        this.autor = autor;
        this.numeroPaginas = numeroPaginas;
    }

    // Método para mostrar información
    public void mostrarInformacion() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Número de páginas: " + numeroPaginas);
        System.out.println();
    }

    // Método para actualizar el número de páginas con validación
    public void actualizarPaginas(int nuevasPaginas) {
        if (nuevasPaginas > 0) {
            this.numeroPaginas = nuevasPaginas;
            System.out.println("Número de páginas actualizado correctamente.");
        } else {
            System.out.println("Error: El número de páginas debe ser mayor que cero.");
        }
    }
}
