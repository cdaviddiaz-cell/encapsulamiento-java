public class ejercicio_4 {
    public static void main(String[] args) {
        // Instanciar un objeto de tipo Vehiculo
        Vehiculo vehiculo = new Vehiculo("Toyota", "Corolla", 0);

        // Mostrar estado inicial
        vehiculo.mostrarEstado();

        // Acelerar varias veces
        vehiculo.acelerar(50);
        vehiculo.mostrarEstado();

        vehiculo.acelerar(100);
        vehiculo.mostrarEstado();

        vehiculo.acelerar(60); // Intentar exceder el límite
        vehiculo.mostrarEstado();

        // Frenar
        vehiculo.frenar(30);
        vehiculo.mostrarEstado();

        vehiculo.frenar(150); // Intentar frenar por debajo de 0
        vehiculo.mostrarEstado();
    }
}

class Vehiculo {
    private String marca;
    private String modelo;
    private int velocidad;
    private static final int VELOCIDAD_MAXIMA = 200;

    // Constructor
    public Vehiculo(String marca, String modelo, int velocidad) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = velocidad;
    }

    // Método para acelerar con límite máximo
    public void acelerar(int incremento) {
        if (velocidad + incremento <= VELOCIDAD_MAXIMA) {
            velocidad += incremento;
            System.out.println("Vehículo acelerado en " + incremento + " km/h.");
        } else {
            System.out.println("No se puede acelerar: se excedería la velocidad máxima de " + VELOCIDAD_MAXIMA + " km/h.");
        }
    }

    // Método para frenar sin permitir valores negativos
    public void frenar(int decremento) {
        if (velocidad - decremento >= 0) {
            velocidad -= decremento;
            System.out.println("Vehículo frenado en " + decremento + " km/h.");
        } else {
            System.out.println("No se puede frenar: la velocidad no puede ser negativa.");
        }
    }

    // Método para mostrar el estado actual
    public void mostrarEstado() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad actual: " + velocidad + " km/h");
        System.out.println();
    }
}