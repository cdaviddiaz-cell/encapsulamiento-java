public class ejercicio_3 {
    public static void main(String[] args) {
        // Instanciar un objeto de tipo Producto
        Producto producto = new Producto("Laptop", 1500.0, 10);

        // Mostrar información inicial
        producto.mostrarInformacion();

        // Modificar el precio con un valor válido
        producto.asignarPrecio(1600.0);
        producto.mostrarInformacion();

        // Intentar asignar un precio inválido
        producto.asignarPrecio(-100.0);
        producto.mostrarInformacion();
    }
}

class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    // Constructor
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Método para asignar un nuevo precio con validación
    public void asignarPrecio(double nuevoPrecio) {
        if (nuevoPrecio >= 0) {
            this.precio = nuevoPrecio;
            System.out.println("Precio actualizado correctamente.");
        } else {
            System.out.println("Error: El precio no puede ser negativo.");
        }
    }

    // Método para mostrar la información completa del producto
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Precio: $" + precio);
        System.out.println("Cantidad en inventario: " + cantidad);
        System.out.println();
    }
}